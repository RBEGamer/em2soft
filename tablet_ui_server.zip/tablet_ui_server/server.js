var express = require('express');
var app = express();
var path = require('path');
var server = require('http').createServer(app);
var io = require('socket.io')(server);
var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var sessionstore = require('sessionstore');
var os = require("os");
var chalk = require('chalk');
var mqtt = require('mqtt');
var config = require('./config.json');
var uuidv1 = require('uuid/v1');
var got = require('got');
var mqtt = require('mqtt');
//var client = mqtt.connect(config.mqtt_server || 'mqtt://127.0.0.1');
var fs = require('fs');


//const rosnodejs = require('rosnodejs');
//const std_msgs = rosnodejs.require('std_msgs').msg;







//{"display":{"curr_kmh":0,"curr_kn":0,"alert":0,"motor":1,"light":0, "alert_msg":"12m3"}}
var VERSION = 0.2;

var port = process.env.PORT || config.webserver_default_port || 3000;

//----------------------------- EXPRESS APP SETUP ------------------------------------------//
app.set('trust proxy', 1);
app.use(function (req, res, next) {
    if (!req.session) {
        return next(); //handle error
    }
    next(); //otherwise continue
});
app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);
// Routing
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'ssshhfddghjhgewretjrdhfsgdfadvsgvshthhh',
    store: sessionstore.createSessionStore(),
    resave: true,
    saveUninitialized: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

server.listen(port, function () {
    console.log('Server listening at port %d', port);
});

var rosnode = null;
var pub = null;


var json = {
    kn:101,
    kmh:10,
    kompressordruck:3.12,
    breaklevel:1,
    direction:0,
    state_v0:1,
    state_v1: 0,
    state_v2: 0,
    state_v3: 1,
    ctl:0,
    asc_state:0,
    fire_detcted:0,
    temperature:23.5,
    batt_charge:36.3,
    light_state:1,
    emergencybrake:0,
    asc_rest_dist:20.0,
    kompressorstate:0,
    lightstate:0,
    kompressor_power_state:0,
    emergencybrakereset:0,
    hupe_state:0


};

function randomIntFromInterval(min, max) { // min and max included 
    return Math.floor(Math.random() * (max - min + 1) + min);
}


var khm_last = json.kmh;
var brk_step = 0.0;

var upd_int = setInterval(() => {

        if (json.km > 20.0) {
            json.km = 20.0;
        } else if (json.km <= 0.1) {
            json.km = 0.0;
        }
    
    


    io.emit('broadcast', {
        display: {
            kn: json.kn.toFixed(2),
            kmh: json.kmh.toFixed(2),
            kompressordruck: json.kompressordruck.toFixed(2 ),
            breaklevel: json.breaklevel,
            direction: json.direction,
            state_v0: json.state_v0,
            state_v1: json.state_v1,
            state_v2: json.state_v2,
            state_v3: json.state_v3,
            ctlmode: 0,
            asc_state: json.asc_state,
            fire_detcted: json.fire_detcted,
            temperature: json.temperature.toFixed(2),
            batt_charge: json.batt_charge.toFixed(2),
            light_state: json.light_state,
            asc_rest_dist: json.asc_rest_dist.toFixed(2),
            emergencybrake: json.emergencybrake,
            kompressorstate: json.kompressorstate,
            lightstate: json.lightstate,
            kompressor_power_state: json.kompressor_power_state,
            emergencybrakereset: json.emergencybrakereset,
            hupe_state: json.hupe_state

        }
    });


    //SIMULATE TEMP
    json.temperature = randomIntFromInterval(23,25);

    //SIMULATE KHM
    json.kn = khm_last - json.kmh;
    khm_last = json.kmh*10.0;
    if (json.asc_state != 2) {
    json.kmh += randomIntFromInterval(-10, 10) * 0.05;
    }else{
        //ASC ACTIVE
        json.kmh -= json.asc_rest_dist*0.01;
    }
    //SIMLUATE BATTCHARGE
    json.batt_charge = 13.2 +json.kn*0.4;

    //SIMULATE COMPRESSOR STATE
    if (json.kompressordruck < 3.5){
        json.kompressorstate = 1;
    } else if (json.kompressordruck > 7.5){
        json.kompressorstate = 0;
    }
    if (json.kompressorstate == 1){
        json.kompressordruck += (Math.floor(Math.random() * 6) + 1) * 0.05;
    }else{
        json.kompressordruck -= (Math.floor(Math.random() * 2) + 1) * 0.02;
    }






    //SIMULATE ASC
    if (json.asc_state == 2 && json.asc_rest_dist > 0.0){
        json.asc_rest_dist -= 0.4;
        json.kmh -= brk_step;
        if (json.kmh < 1.0){
            json.kmh = (Math.floor(Math.random() * 10) + 1) * 0.1;
        }

        if (json.asc_rest_dist <= 10.0) {
            json.state_v0 = true;
            json.state_v1 = false;
            json.state_v2 = false;
            json.state_v3 = false;
        }

        if (json.asc_rest_dist <= 7.0) {
            json.state_v0 = true;
            json.state_v1 = false;
            json.state_v2 = false;
            json.state_v3 = true;
        }

        if (json.asc_rest_dist <= 2.0){
            json.state_v0 = true;
            json.state_v1 = true;
            json.state_v2 = true;
            json.state_v3 = true;
        }
        if (json.asc_rest_dist <= 0.0){
            json.asc_rest_dist = 20.0;
            json.asc_state = 0; 
            json.kmh = 10.0;
        }


    }
},200);


// Register node with ROS master
/*
rosnodejs.initNode('/tablet_node')
    .then((rosNode) => {
        rosnode = rosNode;

        pub = rosnode.advertise('/uimsg', std_msgs.String)
        // Create ROS subscriber on the 'chatter' topic expecting String messages
        let sub = rosNode.subscribe('state', std_msgs.String,
            (data) => { // define callback execution
              //   rosnodejs.log.info('broadcast I heard: [' + data.data + ']');

                var json = data.data;
                try {
                    json = JSON.parse(data.data);
                } catch (error) {

                }

                var ctl = 0;
                if (json.ctlmode) {
                    ctl = 0;
                } else {
                    ctl = 1;
                }
                io.emit('broadcast', {
                    display: {
                        kn: json.kn,
                        kmh: json.kmh,
                        kompressordruck: json.kompressordruck,
                        breaklevel: json.breaklevel,
                        direction: json.direction,
                        state_v0: json.state_v0,
                        state_v1: json.state_v1,
                        state_v2: json.state_v2,
                        state_v3: json.state_v3,
                        ctlmode: ctl,
                        asc_state: json.asc_state,
                        fire_detcted: json.fire_detcted,
                        temperature: json.temperature,
                        batt_charge: json.batt_charge,
                        light_state: json.light_state,
                        asc_rest_dist: json.asc_rest_dist,
                        emergencybrake: json.emergencybrake,
                        kompressorstate: json.kompressorstate,
                        lightstate: json.lightstate,
                        kompressor_power_state:json.kompressor_power_state,
                        emergencybrakereset:json.emergencybrakereset,
                        hupe_state:json.hupe_state

                    }
                });
            }
        );
    });

*/



var last_update = Math.round(new Date().getTime() / 1000);


app.get('/', function (req, res) {
    sess = req.session;
    res.render('index.ejs', {
    });
});


app.get('/break', function (req, res) {
    sess = req.session;
    res.render('emergencyctl.ejs', {
    });
});




io.on('connection', (socket) => {
    socket.on('disconnect', function () {
        console.log('user disconnected');
    });



    socket.on('event', function (_msg) {
        if (_msg.state == undefined){
            _msg.state = -1;
        }
        console.log(JSON.stringify(_msg )+ ' event');

        

        if (_msg.event == "ctlmode") {
            if (json.ctlmode) {
                json.ctlmode = 0;
            } else {
                json.ctlmode = 1;
            }
        }


        if (_msg.event == "dirch"){
            if (json.direction) {
                json.direction = 0;
            } else {
                json.direction = 1;
            }
        }

        if (_msg.event == "asc") {
            if (json.asc_state == 0) {
                json.asc_state = 1;
            } else if (json.asc_state == 1) {
                json.asc_state = 2;


                brk_step = json.kmh /(json.asc_rest_dist / 0.3)  ;
                console.log(brk_step);
            }else{
                json.asc_state = 0;
            }
        }
        
        
        if (_msg.event == "brkstep1"){
            json.state_v0 = true;
            json.state_v1 = false;
            json.state_v2 = false;
            json.state_v3 = false;
        } else if (_msg.event == "brkstep2") {
            json.state_v0 = true;
            json.state_v1 = false;
            json.state_v2 = true;
            json.state_v3 = false;
        } else if (_msg.event == "brkstep3") {
            json.state_v0 = true;
            json.state_v1 = true;
            json.state_v2 = true;
            json.state_v3 = false;
        } else if (_msg.event == "brkstep4") {
            json.state_v0 = true;
            json.state_v1 = true;
            json.state_v2 = true;
            json.state_v3 = true;
        }else{
            json.state_v0 = false;
            json.state_v1 = false;
            json.state_v2 = false;
            json.state_v3 = false;
        }
      

    });


});
//TODO BUTTONS FÜR MANUELL SC_HALTEN EINBAUEN


function RESET_ALL() {
    last_update = Math.round(new Date().getTime() / 1000);
}
RESET_ALL(); //AUSGANGSZUSTAND




