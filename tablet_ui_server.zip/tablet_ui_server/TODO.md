## TODO



* coorperate design
* serial schnittstelle
* updates an alle senden
* cmd für motor aus state converteiren
* arduino sketch für die relais
